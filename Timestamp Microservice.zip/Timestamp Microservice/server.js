const express = require('express');
const app = express();
const apiRoutes = require('./routes/api');

// Enable CORS to allow external API testing (optional)
const cors = require('cors');
app.use(cors({ optionsSuccessStatus: 200 }));

// Serve static files from the 'public' directory
app.use(express.static('public'));

// API routes
app.use('/api', apiRoutes);

// Default route for the base URL
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// Start server on a specific port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
