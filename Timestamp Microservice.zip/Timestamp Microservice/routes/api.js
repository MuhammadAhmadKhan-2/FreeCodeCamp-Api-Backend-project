const express = require('express');
const router = express.Router();

// Handle date parsing and responses
router.get('/:date?', (req, res) => {
  const dateParam = req.params.date;
  let date;

  // Check if the dateParam exists
  if (!dateParam) {
    // If no date is provided, use the current date
    date = new Date();
  } else {
    // Check if dateParam is a valid timestamp or a date string
    if (!isNaN(dateParam)) {
      date = new Date(parseInt(dateParam));
    } else {
      date = new Date(dateParam);
    }
  }

  // Check if date is valid
  if (date.toString() === 'Invalid Date') {
    return res.json({ error: 'Invalid Date' });
  }

  // Respond with the JSON format
  res.json({
    unix: date.getTime(),
    utc: date.toUTCString(),
  });
});

module.exports = router;
